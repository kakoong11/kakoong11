package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import office.*;

public class UserDAO {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	private String url ,user, passwd;
	
	//데이터 베이스 접속
	public UserDAO() {
		try {
			url = "jdbc:oracle:thin:@localhost:1521:xe";
			user = "office";
			passwd = "dteam";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, passwd);
		} catch (Exception e) {
			System.out.println("오라클 접속 드라이버를 찾을 수 없음.");
		}
	}
	
	//닫는 메소드
	private void close() {
		try {
			if(rs != null)
				rs.close();
			if(pstmt != null)
				pstmt.close();
			if(conn != null)
				conn.close();
		} catch(Exception e) {
			System.out.println("닫기 오류");
		}
	}
	//로그인
	public int login(String uEmail, String uPassword) {
		String sql = "SELECT PASSWORD FROM USER_ACCOUNT WHERE E_MAIL = ?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, uEmail);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getString(1).equals(uPassword)) {
					//로그인 성공
					return 1;
				} else {
					//비밀번호 틀림
					return 0;
				}
			}
			//아이디가 없음
			return -1;
		} catch (Exception e) {
			System.out.println("로그인 오류");
		}
		close();
		//데이터 베이스 오류
		return -2;
	}
	
	//회원가입
	public int join(User_account user_account) {
		String sql = "INSERT INTO USER_ACCOUNT VALUES(?, ?, ?, ?, ?)";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user_account.getuEmail());
			pstmt.setString(2, user_account.getuPassword());
			pstmt.setString(3, user_account.getuName());
			pstmt.setString(4, user_account.getuPhone());
			pstmt.setString(5, "user");
			return pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("회원가입 오류");
		}
		close();
		//아이디가 있는 경우
		return -1;
	}
	
	//회원 정보 수정
	public int updateUser(User_account user_account) {
		String sql = "UPDATE USER_ACCOUNT SET PASSWORD = ?, USER_NAME = ?, PHONE = ? WHERE E_MAIL= ?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user_account.getuPassword());
			pstmt.setString(2, user_account.getuName());
			pstmt.setString(3, user_account.getuPhone());
			pstmt.setString(4, user_account.getuEmail());
			return pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("회원정보수정 오류");
		}
		close();
		//데이터베이스 오류
		return -1;		
	}
	
	//회원 탈퇴 및 삭제
	public int deleteUser(User_account user_account) {
		//비번 일치 여부 확인을 위한 비번 셀렉
		String sql = "SELECT PASSWORD FROM USER_ACCOUNT WHERE E_MAIL = ?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user_account.getuEmail());
			rs = pstmt.executeQuery();

			if(rs.next()) {
				//비밀번호 일치하면 삭제
				if(rs.getString(1).equals(user_account.getuPassword())) {
					String sql1 = "DELETE FROM USER_ACCOUNT WHERE E_MAIL = ?";
					pstmt = conn.prepareStatement(sql1);
					pstmt.setString(1, user_account.getuEmail());
					rs = pstmt.executeQuery();
					//삭제 성공
					return 1;
				} else {
					//비밀번호 틀림
					return 0;
				}
			}
		} catch (Exception e) {
			System.out.println("삭제 오류");
		}
		close();
		//데이터 베이스 오류
		return -1;
		
	}
}
