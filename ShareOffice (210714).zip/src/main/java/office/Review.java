package office;
import java.sql.Timestamp;

//리뷰
public class Review {
	//리뷰 변수설정
	private int rNum, rRating;
	private String rContent, rEmail;
	private Timestamp rRegdate;
	
	//생성자
	public Review(int rNum, int rRating, String rContent, String rEmail, Timestamp rRegdate) {
		super();
		this.rNum = rNum;
		this.rRating = rRating;
		this.rContent = rContent;
		this.rEmail = rEmail;
		this.rRegdate = rRegdate;
	}

	//세팅/호출 메소드
	public int getrNum() {
		return rNum;
	}

	public void setrNum(int rNum) {
		this.rNum = rNum;
	}

	public int getrRating() {
		return rRating;
	}

	public void setrRating(int rRating) {
		this.rRating = rRating;
	}

	public String getrContent() {
		return rContent;
	}

	public void setrContent(String rContent) {
		this.rContent = rContent;
	}

	public String getrEmail() {
		return rEmail;
	}

	public void setrEmail(String rEmail) {
		this.rEmail = rEmail;
	}

	public Timestamp getrRegdate() {
		return rRegdate;
	}

	public void setrRegdate(Timestamp rRegdate) {
		this.rRegdate = rRegdate;
	}
}
